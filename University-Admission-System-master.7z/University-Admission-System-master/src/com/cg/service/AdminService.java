package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.dto.Courses;
import com.cg.dto.Schedule;

public interface AdminService {
	public boolean verifyUser(String username,String Password,String role);
	public List<Courses> viewCourses();
	public String addCourse(int CourseId,String ProgramName,String description,String applicant_eligibility,int duration,String degree_certificate_offered);
	public String deleteCourse(int course_id);
	public String addSchedule(int Scheduled_program_id,String ProgramName, String Location,String start_date,  String end_date,int sessions_per_week );
	public String deleteSchedule(int Scheduled_program_id);
	public List<Schedule> viewSchedule();
}
