package com.cg.UI;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import javax.xml.bind.ValidationException;

import com.cg.service.ApplicantServiceImpl;
import com.cg.service.MACService;
import com.cg.service.MACServiceImpl;
import com.cg.Validation.UniversityAdmissionValidation;
import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.Schedule;
import com.cg.service.AdminService;
import com.cg.service.AdminServiceImpl;
import com.cg.service.ApplicantService;

public class MainUI {
	public static void main(String args[])
	{
		ApplicantService appser=new ApplicantServiceImpl();
		MACService mser=new MACServiceImpl();
		AdminService admin = new AdminServiceImpl();
		UniversityAdmissionValidation uav=new UniversityAdmissionValidation();
		Scanner sc=new Scanner(System.in);
		System.out.println("**********************Welcome to University Admission System*************************");
		do{
			try{
				System.out.println("1. For Applicant");
				System.out.println("2. For MAC");
				System.out.println("3. For Admin");
				System.out.println("4. Exit");
				System.out.println("Enter your Choice");
				String user=sc.next();
				switch(user){
				case "1":
					boolean applicant_form = true;
					boolean flag2=true;
					while(applicant_form){
						System.out.println("1. View the courses");
						System.out.println("2. Apply for the courses");
						System.out.println("3. View the status");
						System.out.println("4. for Exit");
						String choice=sc.next();
						String full_name="";
						String date="";
						String highest_qualification="";
						float marks_obtained=0f;
						String email_id="";
						switch(choice){
						case "1":
							List<Courses> list=appser.viewCourses();
							//System.out.println(list);
							System.out.println(String.format("%-15s%-15s%-30s%-25s%-15s%-15s","CourseId", "ProgramName", "description", "applicant_eligibility","duration","degree_certificate_offered"));
							for(Courses course : list) {
							System.out.println(String.format("%-15s%-15s%-30s%-25s%-15d%-15s",course.getCourseId(),course.getProgramName(),course.getDescription(),course.getApplicant_eligibility(),course.getDuration(),course.getDegree_certificate_offered()));
							}
							System.out.println("Make a note of courseId for applying for a course");
							break;
						case "2":
							do{
								try
								{
									System.out.println("Enter your full name");
									if(flag2==true)
										sc.nextLine();
									flag2=false;
									full_name=sc.next();
									if(!uav.isValidName(full_name))
									{
										System.err.println("Enter valid Name");
										flag2=true;
									}
								}
								catch(InputMismatchException e)
								{
									System.err.println("Enter valid name");
									flag2=true;
								}
							}while(flag2);
	
							do{
								try
								{
									System.out.println("Enter the date of birth in format mm/dd/yyyy");
									if(flag2==true)
										sc.nextLine();
									flag2=false;
									date=sc.next();
									
									if(!uav.isValidDate(date))
									{
										System.err.println("Enter valid Date");
										flag2=true;
									}
								}
								catch(InputMismatchException e)
								{
									System.err.println("Enter valid Date");
									flag2=true;
								}
							}while(flag2);
	
							do{
								try
								{
									System.out.println("Enter the highest qualification in higherSchool/Graduation");
									if(flag2==true)
										sc.nextLine();
									flag2=false;
									highest_qualification=sc.next();
									
									if(!uav.isValidHighestQualification(highest_qualification))
									{
										System.err.println("Enter valid highest Qualification");
										flag2=true;
									}
								}
								catch(InputMismatchException e)
								{
									System.err.println("Enter valid highest Qualification");
									flag2=true;
								}
							}while(flag2);
							
							do{
								try
								{
									System.out.println("Enter the marks obtained in percentage");
									if(flag2==true)
										sc.nextLine();
									flag2=false;
									marks_obtained=sc.nextFloat();
									
									if(!uav.isValidMarks(marks_obtained))
									{
										System.err.println("Enter valid marks in range 40 to 100");
										flag2=true;
									}
								}
								catch(InputMismatchException e)
								{
									System.err.println("Enter valid marks in range 40 to 100");
									flag2=true;
								}
							}while(flag2);
							
							System.out.println("Enter the goals");
							String goals=sc.next();
							
							do{
								try
								{
									System.out.println("Enter the email id");
									if(flag2==true)
										sc.nextLine();
									flag2=false;
									email_id=sc.next();
									
									if(!uav.isValidEmail(email_id))
									{
										System.err.println("Enter valid email id");
										flag2=true;
									}
								}
								catch(InputMismatchException e)
								{
									System.err.println("Enter valid email id");
									flag2=true;
								}
							}while(flag2);
							boolean flag9=true;
							while(flag9)
							{
							System.out.println("Enter the course option");
							System.out.println("1. MBA");
							System.out.println("2. Btech");
							System.out.println("3. BBA");
							String opt = sc.next();
							switch(opt){
							case "1":
								Applicant app=appser.applyForCourse(full_name, date, highest_qualification, marks_obtained, goals, email_id,1);	
								//System.out.println(app);
								System.out.println(String.format("%-20s%-25s%-15s%-25s%-20s%-20s%-35s%-25s%-15s%-15s", "Application_id", "full_name", "date_of_birth","highest_qualification","marks_obtained","goals","email_id","Scheduled_program_id","status","Date_Of_Interview"));
								System.out.println(String.format("%-20d%-25s%-15s%-25s%-20f%-20s%-35s%-25d%-15s%-15s",app.getApplication_id(),app.getFull_name(),app.getDate_of_birth(),app.getHighest_qualification(),app.getMarks_obtained(),app.getGoals(),app.getEmail_id(),app.getScheduled_program_id(),app.getStatus(),app.getDate_Of_Interview()));
								flag9=false;
								break;
							case "2":
								Applicant app2=appser.applyForCourse(full_name, date, highest_qualification, marks_obtained, goals, email_id,2);	
								//System.out.println(app2);
								System.out.println(String.format("%-20s%-25s%-15s%-25s%-20s%-20s%-35s%-25s%-15s%-15s", "Application_id", "full_name", "date_of_birth","highest_qualification","marks_obtained","goals","email_id","Scheduled_program_id","status","Date_Of_Interview"));
								System.out.println(String.format("%-20d%-25s%-15s%-25s%-20f%-20s%-35s%-25d%-15s%-15s",app2.getApplication_id(),app2.getFull_name(),app2.getDate_of_birth(),app2.getHighest_qualification(),app2.getMarks_obtained(),app2.getGoals(),app2.getEmail_id(),app2.getScheduled_program_id(),app2.getStatus(),app2.getDate_Of_Interview()));
								flag9=false;
								break;
							case "3":
								Applicant app3=appser.applyForCourse(full_name, date, highest_qualification, marks_obtained, goals, email_id,3);	
								//System.out.println(app3);
								System.out.println(String.format("%-20s%-25s%-15s%-25s%-20s%-20s%-35s%-25s%-15s%-15s", "Application_id", "full_name", "date_of_birth","highest_qualification","marks_obtained","goals","email_id","Scheduled_program_id","status","Date_Of_Interview"));
								System.out.println(String.format("%-20d%-25s%-15s%-25s%-20f%-20s%-35s%-25d%-15s%-15s",app3.getApplication_id(),app3.getFull_name(),app3.getDate_of_birth(),app3.getHighest_qualification(),app3.getMarks_obtained(),app3.getGoals(),app3.getEmail_id(),app3.getScheduled_program_id(),app3.getStatus(),app3.getDate_Of_Interview()));
								flag9=false;
								break;
							default:
								System.out.println("Invalid Choice. Please Enter 1/2/3");
								flag9=true;
								break;
							}
							}
							System.out.println("Enter the course option");
							int courseId=sc.nextInt();
							Applicant app3=appser.applyForCourse(full_name, date, highest_qualification, marks_obtained, goals, email_id,courseId);	
							//System.out.println(app3);
							System.out.println(String.format("%-20s%-25s%-15s%-25s%-20s%-20s%-35s%-25s%-15s%-15s", "Application_id", "full_name", "date_of_birth","highest_qualification","marks_obtained","goals","email_id","Scheduled_program_id","status","Date_Of_Interview"));
							System.out.println(String.format("%-20d%-25s%-15s%-25s%-20f%-20s%-35s%-25d%-15s%-15s",app3.getApplication_id(),app3.getFull_name(),app3.getDate_of_birth(),app3.getHighest_qualification(),app3.getMarks_obtained(),app3.getGoals(),app3.getEmail_id(),app3.getScheduled_program_id(),app3.getStatus(),app3.getDate_Of_Interview()));
							
							
							break;
						case "3":
							int app_id=0;
							do{
								try
								{
									System.out.println("Enter the Applicant id");
									if(flag2==true)
										sc.nextLine();
									flag2=false;
									app_id=sc.nextInt();
								}
								catch(InputMismatchException e)
								{
									System.err.println("Enter valid applicant id");
									flag2=true;
								}
							}while(flag2);
							
							Applicant app=appser.viewStatus(app_id);
							if(app==null)
								System.out.println("List does not contain that id");
							else {
							//System.out.println(app);
							System.out.println(String.format("%-20s%-25s%-15s%-25s%-20s%-20s%-35s%-25s%-15s%-15s", "Application_id", "full_name", "date_of_birth","highest_qualification","marks_obtained","goals","email_id","Scheduled_program_id","status","Date_Of_Interview"));
							System.out.println(String.format("%-20d%-25s%-15s%-25s%-20f%-20s%-35s%-25d%-15s%-15s",app.getApplication_id(),app.getFull_name(),app.getDate_of_birth(),app.getHighest_qualification(),app.getMarks_obtained(),app.getGoals(),app.getEmail_id(),app.getScheduled_program_id(),app.getStatus(),app.getDate_Of_Interview()));
							}
							break;
						case "4":
							applicant_form=false;
							break;
						default:
							System.out.println("Wrong Choice.Enter the Chaoice Again");
							applicant_form=true;
							break;
						}
					}
					break;
				case "2":
					System.out.println("Enter the username");
					String username=sc.next();
					System.out.println("Enter the password");
					String password=sc.next();
					boolean decide=mser.verifyUser(username, password, "MAC");
					boolean flag3=true;
					if(decide == true){
						boolean MAC_form=true;
						while(MAC_form){
							System.out.println("Enter your choice");
							System.out.println("1: View Courses: ");
							System.out.println("2: Get Applicants by Course ID: ");
							System.out.println("3: Schedule Interview: ");
							System.out.println("4: Update Status of the Application: ");
							System.out.println("5: For Exit");
							String choice=sc.next();
							switch(choice){
							case "1":
								List<Courses> list=appser.viewCourses();
								//System.out.println(list);
								System.out.println(String.format("%-15s%-30s%-25s%-15s%-15s", "ProgramName", "description", "applicant_eligibility","duration","degree_certificate_offered"));
								for(Courses course : list) {
								System.out.println(String.format("%-15s%-30s%-25s%-15d%-15s",course.getProgramName(),course.getDescription(),course.getApplicant_eligibility(),course.getDuration(),course.getDegree_certificate_offered()));
								}
								break;
	
							case "2":
								int courseId =0;
								do{
									try
									{
										System.out.println("Enter Course ID :");
										if(flag3==true)
											sc.nextLine();
										flag3=false;
										courseId = sc.nextInt();
									}
									catch(InputMismatchException e)
									{
										System.err.println("Enter valid Course id");
										flag2=true;
									}
								}while(flag3);
								
								List<Applicant> list1=new ArrayList<Applicant>();
								list1=mser.getApplicantsByCourseId(courseId);
								if(list1==null)
									System.out.println("list does not conatin any specific record basis on this id");
								else
								{
								for(Applicant app : list1) {
									System.out.println(String.format("%-20s%-25s%-15s%-25s%-20s%-20s%-35s%-25s%-15s%-15s", "Application_id", "full_name", "date_of_birth","highest_qualification","marks_obtained","goals","email_id","Scheduled_program_id","status","Date_Of_Interview"));
									System.out.println(String.format("%-20d%-25s%-15s%-25s%-20f%-20s%-35s%-25d%-15s%-15s",app.getApplication_id(),app.getFull_name(),app.getDate_of_birth(),app.getHighest_qualification(),app.getMarks_obtained(),app.getGoals(),app.getEmail_id(),app.getScheduled_program_id(),app.getStatus(),app.getDate_Of_Interview()));
								}	
								}
								break;
	
							case "3":
								int app_id=0;
								do{
									try
									{
										System.out.println("Enter the Applicant id");
										if(flag3==true)
											sc.nextLine();
										flag3=false;
										app_id=sc.nextInt();
									}
									catch(InputMismatchException e)
									{
										System.err.println("Enter valid applicant id");
										flag3=true;
									}
								}while(flag3);
								
								String date="";
								do{
									try
									{
										System.out.println("Enter the date of interview in format mm/dd/yyyy");
										if(flag3==true)
											sc.nextLine();
										flag3=false;
										date=sc.next();
										
										if(!uav.isValidDate(date))
										{
											System.err.println("Enter valid Date");
											flag3=true;
										}
									}
									catch(InputMismatchException e)
									{
										System.err.println("Enter valid Date");
										flag3=true;
									}
								}while(flag3);
								
								
								System.out.println(mser.sheduleInterview(app_id,date));
								break;
	
							case "4":
								int app_id1=0;
								do{
									try
									{
										System.out.println("Enter the Applicant id");
										if(flag3==true)
											sc.nextLine();
										flag3=false;
										app_id1=sc.nextInt();
									}
									catch(InputMismatchException e)
									{
										System.err.println("Enter valid applicant id");
										flag3=true;
									}
								}while(flag3);
								System.out.println("Enter Status: 1. Selected 2. Rejected 3. On-Hold ");
								int status=sc.nextInt();
								System.out.println(mser.updateStatus(app_id1,status));
								break;
							case "5":
								MAC_form=false;
								break;
							default:
								System.out.println("Wrong Choice. Enter the Choice Again");
								MAC_form=true;
								break;
							}
						}
					}
					else{
						System.out.println("Invalid Credentials");
					}
					break;
				case "3":
					System.out.println("Enter the username");
					String adminUsername=sc.next();
					System.out.println("Enter the password");
					String adminPassword=sc.next();
					boolean adminDecide=admin.verifyUser(adminUsername, adminPassword, "Admin");
					if(adminDecide==true){
						boolean Admin_form=true;
						while(Admin_form){
							System.out.println("Enter your choice");
							System.out.println("1. View Courses");
							System.out.println("2. Add Course");
							System.out.println("3. Delete Course ");
							System.out.println("4. Add Shedule ");
							System.out.println("5. Delete Schedule");
							System.out.println("6. View Schedules");
							System.out.println("7. for Exit");
							String choice=sc.next();
							int programId = 0;
							String eligibility = null;
							int courseId = 0;
							switch(choice){
							case "1":
								List<Courses> list=admin.viewCourses();
								//System.out.println(list);
								System.out.println(String.format("%-15s%-15s%-30s%-25s%-15s%-15s","CourseId", "ProgramName", "description", "applicant_eligibility","duration","degree_certificate_offered"));
								for(Courses course : list) {
								System.out.println(String.format("%-15s%-15s%-30s%-25s%-15d%-15s",course.getCourseId(),course.getProgramName(),course.getDescription(),course.getApplicant_eligibility(),course.getDuration(),course.getDegree_certificate_offered()));
								}
								break;
							case "2":
								String progName="";
								boolean flag8=true;
								
								while(flag8)
								{
								System.out.println("Enter Program Name");
								System.out.println("Enter 4 for BSC");
								System.out.println("Enter 5 for MSC");
								System.out.println("Enter 6 for Bpharma");
								String choice2=sc.next();
								switch(choice2)
								{
								case "4":
									courseId=4;
									progName="BSC";
									flag8=false;
									break;
								case "5":
									courseId=4;
									progName="MSC";
									flag8=false;
									break;
								case "6":
									courseId=4;
									progName="Bpharma";
									flag8=false;
									break;
								default:
									System.out.println("Invalid Choice. Please Enter 4/5/6");
									flag8=true;
									break;
								}
								}
						
								System.out.println("Add description");
								String desc = sc.next();
								boolean flag7=true;
								while(flag7)
								{
								System.out.println("Enter Application Eligibility");
								System.out.println("Enter 1 for 10th");
								System.out.println("Enter 2 for 12th");
								System.out.println("Enter 3 for graduation");
								String opt=sc.next();
								
								
								switch(opt)
								{
								case "1":
									eligibility="10th";
									flag7=false;
									break;
								case "2":
									eligibility="12th";
									flag7=false;
									break;
								case "3":
									eligibility="Graduation";
									flag7=false;
									break;
								default:
									System.out.println("Invalid Choice. Please Enter 1/2/3");
									flag7=true;
									break;
								}
								}
								
								System.out.println("Enter duration");
								int duration = sc.nextInt();
								System.out.println("Enter Degree Certificate offered");
								String degree = sc.next();
								System.out.println(admin.addCourse(courseId,progName, desc, eligibility, duration, degree));
								break;
							case "3":
								System.out.println("Enter the courseId");
								int course_id= sc.nextInt();
								System.out.println(admin.deleteCourse(course_id));
								break;
							case "4":
								boolean flag6=true;
								String ProgramName="";
								while(flag6)
								{
								System.out.println("Enter Sheduled Program Id and program name");
								System.out.println("1. MBA");
								System.out.println("2. Btech");
								System.out.println("3. BBA");
								String opt1 = sc.next();
							
								switch(opt1)
								{
								case "1":
									programId=1;
									ProgramName="MBA";
									flag6=false;
									break;
								case "2":
									programId=2;
									ProgramName="Btech";
									flag6=false;
									break;
								case "3":
									programId=3;
									ProgramName="BBA";
									flag6=false;
									break;
								default:
									System.out.println("Invalid Choice. Please Enter 1/2/3");
									flag6=true;
									break;
								}
								}
								
								
								System.out.println("Enter Location");
								String loc = sc.next();
								String sDate = null,eDate=null;
								boolean flag5 = false;
								do{
									try
									{
										System.out.println("Enter the start date in format mm/dd/yyyy");
										if(flag5==true)
											sc.nextLine();
										flag2=false;
										sDate=sc.next();
										
										if(!uav.isValidDate(sDate))
										{
											System.err.println("Enter valid Date");
											flag5=true;
										}
									}
									catch(InputMismatchException e)
									{
										System.err.println("Enter valid Date");
										flag5=true;
									}
								}while(flag5);
								do{
									try
									{
										System.out.println("Enter the End date in format mm/dd/yyyy");
										if(flag5==true)
											sc.nextLine();
										flag2=false;
										eDate=sc.next();
										
										if(!uav.isValidDate(sDate))
										{
											System.err.println("Enter valid Date");
											flag5=true;
										}
									}
									catch(InputMismatchException e)
									{
										System.err.println("Enter valid Date");
										flag5=true;
									}
								}while(flag5);
								
								System.out.println("Enter the no sessions per week");
								int dur = sc.nextInt();
								
								System.out.println(admin.addSchedule(programId, ProgramName, loc, sDate, eDate,dur));
								break;
							case "5":
								System.out.println("Enter Scheduled_program_id");
								int Scheduled_program_id=sc.nextInt();
								System.out.println(admin.deleteSchedule(Scheduled_program_id));
								break;
							case "6":
								//System.out.println(admin.viewSchedule());
								List<Schedule> scheduleList = admin.viewSchedule();
								System.out.println(String.format("%-20s%-30s%-15s%-20s%-20s%-20s", "Scheduled_program_id", "ProgramName", "Location","start_date","end_date","sessions_per_week"));
								for(Schedule schedule : scheduleList) {
								System.out.println(String.format("%-20s%-30s%-15s%-20s%-20s%-20d",schedule.getScheduled_program_id(),schedule.getProgramName(),schedule.getLocation(),schedule.getStart_date().toString(),schedule.getEnd_date().toString(),schedule.getSessions_per_week()));
								}
								break;
							case "7":
								Admin_form=false;
								break;
							default:
								System.out.println("Wrong Choice.Enter the Choice again");
								Admin_form=true;
								break;
							}
						}
					}
					else{
						System.out.println("Invalid Credentials");
					}
					break;
				case "4":
					System.exit(0);
				default:
					System.out.println("Invalid Choice. Please Enter 1/2/3/4");
				}
			}
			catch(InputMismatchException e){
				System.err.println("Please enter a valid  choice");
				System.out.println(e);
			}
			catch(Exception e){
				System.err.println("Please enter a valid  choice");
				System.out.println(e);
			}
		}while(true);
	}
}