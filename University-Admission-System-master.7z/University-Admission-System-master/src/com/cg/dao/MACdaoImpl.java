package com.cg.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.dto.Applicant;
import com.cg.dto.LogIn;

public class MACdaoImpl implements MACdao {

	@Override
	public boolean verifyUser(LogIn login) {
	
		Iterator<LogIn> itr=StacticDataBase.getLogin().iterator();
		while(itr.hasNext())
		{
			LogIn obj=itr.next();
			
			if(login.getUserName().equals(obj.getUserName())&&login.getPassword().equals(obj.getPassword())&&login.getRole().equals(obj.getRole()))
			{
				return true;
			}
			
		}
		return false;
	
	}

	@Override
	public List<Applicant> getApplicantsByCourseId(int CourseId) {
		// TODO Auto-generated method stub
		boolean flag=false;
		
		List<Applicant> list1=new ArrayList<Applicant>();
		List<Applicant> list = StacticDataBase.applicant;
		Iterator<Applicant> itr=list.iterator();
		while(itr.hasNext())
		{
			Applicant app=itr.next();
			if(app.getScheduled_program_id() == CourseId){
				list1.add(app);
				flag=true;
			}
		
		}
		if(flag=false)
			return null;
		else
		return list1;
	}

	@Override
	public String sheduleInterview(int applicant, String date) {
		
		List<Applicant> list = StacticDataBase.applicant;
		Iterator<Applicant> itr=list.iterator();
		boolean flag=false;
		while(itr.hasNext()){
			Applicant app=itr.next();
			
			if(app.getApplication_id() == applicant){
				app.setDate_Of_Interview(date);
				flag=true;
			}
		
		}
		if(flag){
			
			return "Interview Scheduled";
		}
		else{
			return "Applicant id is not found";
		}
		
	}

	@Override
	public String updateStatus(int applicationId, int status) {
		// TODO Auto-generated method stub
		String statusValue = "";
		List<Applicant> list = StacticDataBase.applicant;
		Iterator<Applicant> itr=list.iterator();
		while(itr.hasNext()){
			Applicant app=itr.next();
			if(app.getApplication_id() == applicationId){
				if(status == 1) {
					statusValue = "Selected";
				}
				else if(status == 2) {
					statusValue = "Rejected";
				}
				else {
					statusValue = "On-Hold";
				}
				app.setStatus(statusValue);
				return "Status Updated";
			}
			/*else
				return "Id is not present";*/
		}
		return "Application does not Exists";
	}
}
