package com.cg.dao;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.LogIn;
import com.cg.dto.Schedule;

public class AdmindaoImpl implements Admindao {
	List<Courses> list;
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
	EntityManager em=emf.createEntityManager();
	@Override
	public boolean verifyUser(LogIn login) {
	

		Iterator<LogIn> itr=em.createQuery("SELECT a FROM LogIn a",LogIn.class).getResultList().iterator();
		while(itr.hasNext())
		{
			LogIn obj=itr.next();
			
			if(login.getUserName().equals(obj.getUserName())&&login.getPassword().equals(obj.getPassword())&&login.getRole().equals(obj.getRole()))
			{
				return true;
			}
			
		}
		return false;

	}

	@Override
	public String addCourse(Courses course) {
		 list =  em.createQuery("SELECT a FROM Courses a",Courses.class).getResultList();
		boolean flag=false;
		for(Courses cour:list)
		{if(course.getCourseId()==cour.getCourseId())
			flag=true;}
		
		if(flag!=true)
		{
		em.getTransaction().begin();
		em.persist(course);
		em.getTransaction().commit();
		return "Course added sucessfully";}
		else
			return "course with courseId already in the list";
	
	}

	@Override
	public String deleteCourse(int course_id) {
		
	
		boolean flag=false;
		Courses cour=em.find(Courses.class, course_id);
		if(cour!=null)
		{
		em.getTransaction().begin();
		em.remove(cour);
		em.getTransaction().commit();
		flag=true;
		}
		if(flag){
			return "Course deleted sucessfully";
		}
		else{
			return "Can not find course";
		}

		
	}

	@Override
	public String addSchedule(Schedule schedule) {
		boolean flag=false;
	
		List<Schedule> list1= em.createQuery("SELECT a FROM Schedule a",Schedule.class).getResultList();
		for(Schedule sched:list1)
		{if(schedule.getScheduled_program_id()==sched.getScheduled_program_id())
			flag=true;}
		if(flag==false)
		{
			em.getTransaction().begin();
			em.persist(schedule);
			em.getTransaction().commit();
	
		return "Schedule Added Sucessfully";}
		else
			return "Schedule is already exist";
	
}

	@Override
	public String deleteSchedule(int Scheduled_program_id) {
		
		
		boolean flag=false;
		Schedule sech=em.find(Schedule.class, Scheduled_program_id);
		if(sech!=null)
		{
		em.getTransaction().begin();
		em.remove(sech);
		em.getTransaction().commit();
		flag=true;
		}
		if(flag){
			return "Schedule deleted sucessfully";
		}
		else{
			return "Can not found the Schedule program id";
		}
	}

	@Override
	public List<Courses> viewCourses() {
		// TODO Auto-generated method stub
		return   em.createQuery("SELECT a FROM Courses a",Courses.class).getResultList();
	}

	@Override
	public List<Schedule> viewSchedule() {
		
		return  em.createQuery("SELECT a FROM Schedule a",Schedule.class).getResultList();
	}

}
