package com.cg.dao;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.LogIn;

public class MACdaoImpl implements MACdao {

	EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
	EntityManager em=emf.createEntityManager();
	@Override
	public boolean verifyUser(LogIn login) {
	
		Iterator<LogIn> itr=em.createQuery("SELECT a FROM LogIn a",LogIn.class).getResultList().iterator();
		while(itr.hasNext())
		{
			LogIn obj=itr.next();
			
			if(login.getUserName().equals(obj.getUserName())&&login.getPassword().equals(obj.getPassword())&&login.getRole().equals(obj.getRole()))
			{
				return true;
			}
			
		}
		return false;
	
	}

	@Override
	public List<Applicant> getApplicantsByCourseId(int CourseId) {
		// TODO Auto-generated method stub
		boolean flag=false;
		
		List<Applicant> list1=new ArrayList<Applicant>();
		List<Applicant> list = em.createQuery("select a from Applicant a",Applicant.class).getResultList();
		Iterator<Applicant> itr=list.iterator();
		while(itr.hasNext())
		{
			Applicant app=itr.next();
			if(app.getScheduled_program_id() == CourseId){
				list1.add(app);
				flag=true;
			}
		
		}
		if(flag=false)
			return null;
		else
		return list1;
	}

	@Override
	public String sheduleInterview(int applicant, String date) {
		boolean flag=false;
		Applicant app=em.find(Applicant.class, applicant);
		if(app!=null)
		{
		em.getTransaction().begin();
		app.setDate_Of_Interview(date);
		em.getTransaction().commit();
		flag=true;
		}
		
		
			
		
		if(flag){
			
			return "Interview Scheduled";
		}
		else{
			return "Applicant id is not found";
		}
		
	}

	@Override
	public String updateStatus(int applicationId, int status) {
		// TODO Auto-generated method stub
		String statusValue = "";
		List<Applicant> list = em.createQuery("select a from Applicant a",Applicant.class).getResultList();
		Iterator<Applicant> itr=list.iterator();
		while(itr.hasNext()){
			Applicant app=itr.next();
		
			if(app.getApplication_id() == applicationId){
				if(status == 1) {
					statusValue = "Selected";
				}
				else if(status == 2) {
					statusValue = "Rejected";
				}
				else {
					statusValue = "On-Hold";
				}
				em.getTransaction().begin();
				app.setStatus(statusValue);
				em.getTransaction().commit();
				return "Status Updated";
			}
			
		}
		
		return "Application does not Exists";
	}
}
