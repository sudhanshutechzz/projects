package com.cg.dto;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="programs_scheduled")
public class Schedule {
	@Id
	@Column(name="Scheduled_program_id")
	private int Scheduled_program_id;
	@Column(name="program_name")
	private String ProgramName; 
	@Column(name="loacation")
	private String Location;
	@Column(name="start_date")
	private String start_date;
	@Column(name="end_date")
	private String end_date ;
	@Column(name="sessions_per_week")
	private int sessions_per_week;
	public Schedule(){
		
	}
	public Schedule(int scheduled_program_id, String programName, String location, String start_date,
			String end_date, int sessions_per_week) {
		super();
		Scheduled_program_id = scheduled_program_id;
		ProgramName = programName;
		Location = location;
		this.start_date = start_date;
		this.end_date = end_date;
		this.sessions_per_week = sessions_per_week;
	}
	public int getScheduled_program_id() {
		return Scheduled_program_id;
	}
	public void setScheduled_program_id(int scheduled_program_id) {
		Scheduled_program_id = scheduled_program_id;
	}
	public String getProgramName() {
		return ProgramName;
	}
	public void setProgramName(String programName) {
		ProgramName = programName;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	public int getSessions_per_week() {
		return sessions_per_week;
	}
	public void setSessions_per_week(int sessions_per_week) {
		this.sessions_per_week = sessions_per_week;
	}
	@Override
	public String toString() {
		return "CoursesSheduled [Scheduled_program_id=" + Scheduled_program_id + ", ProgramName=" + ProgramName
				+ ", Location=" + Location + ", start_date=" + start_date + ", end_date=" + end_date
				+ ", sessions_per_week=" + sessions_per_week + "]"+"\n";
	}
	
}
