package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "programs_offered")
public class Courses {
	@Id
	@Column(name="course_id")
	private int courseId;
	@Column(name="program_name")
	private String ProgramName;
	@Column(name="description")
	private String description;
	@Column(name="applicant_eligibility")
	private String applicant_eligibility;
	@Column(name="duration")
	private int duration;
	@Column(name="degree_certificate_offered")
	private String degree_certificate_offered;
	public Courses(){
		
	}
	public String getProgramName() {
		return ProgramName;
	}
	
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	/*public Courses(String programName, String description, String applicant_eligibility, int duration,
			String degree_certificate_offered) {
		super();
		ProgramName = programName;
		this.description = description;
		this.applicant_eligibility = applicant_eligibility;
		this.duration = duration;
		this.degree_certificate_offered = degree_certificate_offered;
	}*/
	
	public void setProgramName(String programName) {
		ProgramName = programName;
	}
	public Courses(int courseId, String programName, String description, String applicant_eligibility, int duration,
			String degree_certificate_offered) {
		super();
		this.courseId = courseId;
		ProgramName = programName;
		this.description = description;
		this.applicant_eligibility = applicant_eligibility;
		this.duration = duration;
		this.degree_certificate_offered = degree_certificate_offered;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getApplicant_eligibility() {
		return applicant_eligibility;
	}
	public void setApplicant_eligibility(String applicant_eligibility) {
		this.applicant_eligibility = applicant_eligibility;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getDegree_certificate_offered() {
		return degree_certificate_offered;
	}
	public void setDegree_certificate_offered(String degree_certificate_offered) {
		this.degree_certificate_offered = degree_certificate_offered;
	}
	@Override
	public String toString() {
		return "Courses [ProgramName=" + ProgramName + ", description=" + description + ", applicant_eligibility="
				+ applicant_eligibility + ", duration=" + duration + ", degree_certificate_offered="
				+ degree_certificate_offered + "]"+"\n";
	}
	
}
